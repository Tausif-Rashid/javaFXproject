package server;

import SearchFunctions.Movie;
import SearchFunctions.MovieList;
import SearchFunctions.ProdCompanyList;
import utils.SocketWrapper;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class ServerMain {


    private ServerSocket serverSocket;

    // public  static ProdCompanyList prodCompanyList;
    public static List<Movie> movies = new ArrayList<>(); //all movies from file

    ServerMain() {
        try {
            serverSocket = new ServerSocket(33333);
            while (true) {
                System.out.println("waiting for a client");
                Socket clientSocket = serverSocket.accept(); // gets a client socket, a good idea to  store in hashmap with name bcz multi clients
                System.out.println("client connected");
                serve(clientSocket);
                System.out.println("serve done");
            }
        } catch (Exception e) {
            System.out.println("Server starts:" + e);
        }
    }

    public void serve(Socket clientSocket) throws IOException {
        SocketWrapper socketWrapper = new SocketWrapper(clientSocket); // send the client socket to read thread
        new ReadThreadServer(socketWrapper);
        //new WriteThread(socketWrapper, "Server");
    }


    public void setServerSocket(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }

    // Server searches movie list for company name
    public static List<Movie> searchMovieCompany(List<Movie> longList , String companyName) { //Search with company. return the movie list

        List<Movie> moviesCompany = new ArrayList<>();
        for (Movie movie : longList) {

            if (movie.getProductionCompany().equalsIgnoreCase(companyName))
                moviesCompany.add(movie);

        }

        return moviesCompany;
    }

    public static void main(String[] args) {

        FileAccess fileAccess = new FileAccess();
        //TODO find a way to send desired movies without static

        movies = fileAccess.getMovieList();

        System.out.println("Movie loaded. server starting");

        new ServerMain();
    }

}

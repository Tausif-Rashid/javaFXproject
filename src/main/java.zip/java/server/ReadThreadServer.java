package server;


import SearchFunctions.Movie;
import SearchFunctions.MovieList;
import SearchFunctions.ProdCompanyList;
import utils.DataPacket;
import utils.SocketWrapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadThreadServer implements Runnable {
    private Thread thread;
    private SocketWrapper socketWrapper;

    public ReadThreadServer(SocketWrapper socketWrapper) {
        this.socketWrapper = socketWrapper;
        this.thread = new Thread(this);
        thread.start();
    }

    public void run() {
        try {
            while (true) {
                Object o = socketWrapper.read();
                if (o instanceof DataPacket) {
                    DataPacket obj = (DataPacket) o;
                    System.out.println("READER THREAD: Received: "+ obj.getUserName());



                    List<Movie> newList = ServerMain.searchMovieCompany(ServerMain.movies, obj.getUserName());

                 //TODO find a way to send desired movies without static

                    obj.setMovieList(newList);

                    obj.setValue("Requested movies sent");

                    socketWrapper.write(obj);


                }



            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                socketWrapper.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}




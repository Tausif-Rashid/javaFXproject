package Client;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginViewController {
    private Stage stageCurrent;

    public Stage getStageCurrent() {
        return stageCurrent;
    }

    public void setStageCurrent(Stage stage) {
        this.stageCurrent = stage;
    }

    public void onBackButtonClick(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("main_menu_view.fxml")); //MovieDatabaseMain.class
        Parent root = loader.load();

        // Loading the controller
        MainMenuController controller = loader.getController();
        controller.setStageCurrent(stageCurrent);

        // Set the primary stage
        stageCurrent.setTitle("Login");
        stageCurrent.setScene(new Scene(root, 400, 250));
        stageCurrent.show();
    }
}

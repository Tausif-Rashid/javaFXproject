package Client;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class MainMenuController {
    @FXML
    private Label welcomeText;

    private Stage stageCurrent;

    public Stage getStageCurrent() {
        return stageCurrent;
    }

    public void setStageCurrent(Stage stageCurrent) {
        this.stageCurrent = stageCurrent;
    }

    public void onLoginButtonClick(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("login_view.fxml")); //MovieDatabaseMain.class
        Parent root = loader.load();

        // Loading the controller
        LoginViewController controller = loader.getController();
        controller.setStageCurrent(stageCurrent);

        // Set the primary stage
        stageCurrent.setTitle("Login");
        stageCurrent.setScene(new Scene(root, 400, 250));
        stageCurrent.show();

    }

    public void onExitButtonClick(ActionEvent actionEvent) {

        Platform.exit();
    }
}
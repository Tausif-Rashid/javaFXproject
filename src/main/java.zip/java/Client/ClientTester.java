package Client;

import SearchFunctions.Movie;
import utils.DataPacket;
import utils.SocketWrapper;
import server.ReadThreadServer;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ClientTester {

    public static List <Movie> moviesOfCompany = new ArrayList<>();

    Scanner scanner= new Scanner(System.in);

    public List<Movie> getMoviesOfCompany() {
        return moviesOfCompany;
    }

    public static void setMoviesOfCompany(List<Movie> moviesOfCompany) {
        ClientTester.moviesOfCompany = moviesOfCompany;
    }

    public ClientTester(String serverAddress, int serverPort) {
        try {
            SocketWrapper socketWrapper = new SocketWrapper(serverAddress, serverPort);

            DataPacket msg =new DataPacket();

            msg.setId(100);

            System.out.println("Enter username : ");

            msg.setUserName(scanner.nextLine());
            socketWrapper.write(msg);
            new ReadThread(socketWrapper);
           // new WriteThread(socketWrapper, "Client");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        String serverAddress = "127.0.0.1";
        int serverPort = 33333;

        try
        {
            new ClientTester(serverAddress, serverPort);

        }
        catch (Exception e)
        {
            System.out.println("Could not connect to server");
        }
        }
}

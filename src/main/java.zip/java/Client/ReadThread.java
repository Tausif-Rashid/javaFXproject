package Client;

import SearchFunctions.Movie;
import utils.DataPacket;
import utils.SocketWrapper;

import java.io.IOException;

public class ReadThread implements Runnable {

    private Thread thread;
    private SocketWrapper socketWrapper;

    public ReadThread(SocketWrapper socketWrapper) {
        this.socketWrapper = socketWrapper;
        this.thread = new Thread(this);
        thread.start();
    }

    public void run() {
        try {
            while (true) {
                Object o = socketWrapper.read();

                if (o instanceof DataPacket) {
                    DataPacket obj = (DataPacket) o;
                    System.out.println("Received: " + obj.getId() + ", " + obj.getValue());


                    for (Movie c : obj.getMovieList()) {

                        System.out.println(c.getTitle());
                    }

                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                socketWrapper.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

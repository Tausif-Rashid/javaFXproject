package SearchFunctions;

import java.util.ArrayList;
import java.util.List;

public class ProductionCompany {

    private String companyName;

    private List<Movie> companyMovie = new ArrayList<>();

    private int movieCount;

    private long totalProfit;

    private int LatestReleaseYear;
    private int MaxRevenue;


    ProductionCompany(String name)
    {
        companyName=name;

        movieCount=0;
        totalProfit=0;
        LatestReleaseYear=0;
        MaxRevenue=0;

    }
    void companyNewMovieList(List<Movie> list)
    {
        for (Movie mov: list) {
            if(companyName.equalsIgnoreCase(mov.getProductionCompany()))
            {
                companyMovie.add(mov);
                movieCount++;
                totalProfit+=mov.getProfit();
                if(LatestReleaseYear < mov.getYearOfRelease())LatestReleaseYear=mov.getYearOfRelease();
                if(MaxRevenue < mov.getRevenue())MaxRevenue=mov.getRevenue();
            }
        }
    }
    void addMovieComp(Movie movie)
    {
        companyMovie.add(movie);
        movieCount++;
        totalProfit+=movie.getProfit();
        if(LatestReleaseYear < movie.getYearOfRelease())LatestReleaseYear=movie.getYearOfRelease();
        if(MaxRevenue < movie.getRevenue())MaxRevenue=movie.getRevenue();
    }

    public String getCompanyName() {
        return companyName;
    }

    public List<Movie> getCompanyMovie() {
        return companyMovie;
    }

    public int getMovieCount() {
        return movieCount;
    }

    public long getTotalProfit() {
        return totalProfit;
    }

    public int getLatestReleaseYear() {
        return LatestReleaseYear;
    }

    public int getMaxRevenue() {
        return MaxRevenue;
    }
}
